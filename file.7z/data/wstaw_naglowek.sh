#!/bin/sh
sed -i '1 s/,.*$/, U[V],I[A],Ci[Ah],P[W],Cw[Wh],Rw[Ohm]/' lionlad.txt
