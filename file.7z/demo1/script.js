
const fetchData = () => {
  return fetch(`http://localhost:8086/query?db=testdb&q=SELECT vbus,cur,pow FROM lion where time>now()-60m`)
//  return fetch(`http://localhost:8086/query?db=testdb&q=SELECT "vbus" FROM "lion"`)
    .then( response => {
      if (response.status !== 200) {
        console.log(response);
      }
      return response;
    })
    .then( response => response.json() )
    .then( parsedResponse => {
      const data = [];
      parsedResponse.results[0].series[0].values.map( (elem, i) => {
        let newArr = [];
        newArr.push(new Date(Date.parse(elem[0])));
        newArr.push(elem[1]);
        newArr.push(elem[1]+10);
        data.push(newArr);
      });
      return data;
    })
    .catch( error => console.log(error) );
}

const drawGraph = () => {  let g;
  Promise.resolve(fetchData())
    .then( data => {
      g = new Dygraph(
        document.getElementById("div_g"),
        data,
        {
        //  drawPoints: false,
          title: 'Lion Data',
        //  titleHeight: 32,
        //  ylabel: 'Data [mV] ',
        //  xlabel: 'Date',
          strokeWidth: 1.0,
        //  labels: ['Date', 'Price'],
        });
    });

  window.setInterval( () => {
    console.log(Date.now());
    Promise.resolve(fetchData())
      .then( data => {
        g.updateOptions( { 'file': data } );
      });
  }, 2000);
}

$(document).ready(drawGraph());
